﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SporStokTakip.Models.Entity;

namespace SporStokTakip.Controllers
{
    public class SatisBilgilerisController : Controller
    {
        private SporStokSistemiEntities db = new SporStokSistemiEntities();

        // GET: SatisBilgileris
        public ActionResult Index()
        {
            var satisBilgileri = db.SatisBilgileri.Include(s => s.KartBilgileri).Include(s => s.MusteriBilgileri).Include(s => s.UrunCesidi).Include(s => s.StoktakiUrunler);
            return View(satisBilgileri.ToList());
        }

        // GET: SatisBilgileris/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SatisBilgileri satisBilgileri = db.SatisBilgileri.Find(id);
            if (satisBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(satisBilgileri);
        }

        // GET: SatisBilgileris/Create
        public ActionResult Create()
        {
            ViewBag.KartNumarasi = new SelectList(db.KartBilgileri, "KartNumarasi", "CVC");
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad");
            ViewBag.UrunCesitID = new SelectList(db.UrunCesidi, "UrunCesitID", "UrunAd");
            ViewBag.UrunID = new SelectList(db.StoktakiUrunler, "UrunID", "UrunAd");
            return View();
        }

        // POST: SatisBilgileris/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UrunSatisID,UrunID,UrunCesitID,UyeID,KartNumarasi")] SatisBilgileri satisBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.SatisBilgileri.Add(satisBilgileri);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.KartNumarasi = new SelectList(db.KartBilgileri, "KartNumarasi", "CVC", satisBilgileri.KartNumarasi);
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad", satisBilgileri.UyeID);
            ViewBag.UrunCesitID = new SelectList(db.UrunCesidi, "UrunCesitID", "UrunAd", satisBilgileri.UrunCesitID);
            ViewBag.UrunID = new SelectList(db.StoktakiUrunler, "UrunID", "UrunAd", satisBilgileri.UrunID);
            return View(satisBilgileri);
        }

        // GET: SatisBilgileris/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SatisBilgileri satisBilgileri = db.SatisBilgileri.Find(id);
            if (satisBilgileri == null)
            {
                return HttpNotFound();
            }
            ViewBag.KartNumarasi = new SelectList(db.KartBilgileri, "KartNumarasi", "CVC", satisBilgileri.KartNumarasi);
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad", satisBilgileri.UyeID);
            ViewBag.UrunCesitID = new SelectList(db.UrunCesidi, "UrunCesitID", "UrunAd", satisBilgileri.UrunCesitID);
            ViewBag.UrunID = new SelectList(db.StoktakiUrunler, "UrunID", "UrunAd", satisBilgileri.UrunID);
            return View(satisBilgileri);
        }

        // POST: SatisBilgileris/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UrunSatisID,UrunID,UrunCesitID,UyeID,KartNumarasi")] SatisBilgileri satisBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.Entry(satisBilgileri).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.KartNumarasi = new SelectList(db.KartBilgileri, "KartNumarasi", "CVC", satisBilgileri.KartNumarasi);
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad", satisBilgileri.UyeID);
            ViewBag.UrunCesitID = new SelectList(db.UrunCesidi, "UrunCesitID", "UrunAd", satisBilgileri.UrunCesitID);
            ViewBag.UrunID = new SelectList(db.StoktakiUrunler, "UrunID", "UrunAd", satisBilgileri.UrunID);
            return View(satisBilgileri);
        }

        // GET: SatisBilgileris/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SatisBilgileri satisBilgileri = db.SatisBilgileri.Find(id);
            if (satisBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(satisBilgileri);
        }

        // POST: SatisBilgileris/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            SatisBilgileri satisBilgileri = db.SatisBilgileri.Find(id);
            db.SatisBilgileri.Remove(satisBilgileri);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
