﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SporStokTakip.Models.Entity;

namespace SporStokTakip.Controllers
{
    public class KartBilgilerisController : Controller
    {
        private SporStokSistemiEntities db = new SporStokSistemiEntities();

        // GET: KartBilgileris
        public ActionResult Index()
        {
            var kartBilgileri = db.KartBilgileri.Include(k => k.MusteriBilgileri);
            return View(kartBilgileri.ToList());
        }

        // GET: KartBilgileris/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            KartBilgileri kartBilgileri = db.KartBilgileri.Find(id);
            if (kartBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(kartBilgileri);
        }

        // GET: KartBilgileris/Create
        public ActionResult Create()
        {
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad");
            return View();
        }

        // POST: KartBilgileris/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "KartNumarasi,UyeID,CVC,SonKullanmaTarihi")] KartBilgileri kartBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.KartBilgileri.Add(kartBilgileri);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad", kartBilgileri.UyeID);
            return View(kartBilgileri);
        }

        // GET: KartBilgileris/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            KartBilgileri kartBilgileri = db.KartBilgileri.Find(id);
            if (kartBilgileri == null)
            {
                return HttpNotFound();
            }
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad", kartBilgileri.UyeID);
            return View(kartBilgileri);
        }

        // POST: KartBilgileris/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "KartNumarasi,UyeID,CVC,SonKullanmaTarihi")] KartBilgileri kartBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.Entry(kartBilgileri).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.UyeID = new SelectList(db.MusteriBilgileri, "UyeID", "AdSoyad", kartBilgileri.UyeID);
            return View(kartBilgileri);
        }

        // GET: KartBilgileris/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            KartBilgileri kartBilgileri = db.KartBilgileri.Find(id);
            if (kartBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(kartBilgileri);
        }

        // POST: KartBilgileris/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            KartBilgileri kartBilgileri = db.KartBilgileri.Find(id);
            db.KartBilgileri.Remove(kartBilgileri);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
