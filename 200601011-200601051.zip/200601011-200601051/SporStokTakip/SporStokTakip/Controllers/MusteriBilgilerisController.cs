﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SporStokTakip.Models.Entity;

namespace SporStokTakip.Controllers
{
    public class MusteriBilgilerisController : Controller
    {
        private SporStokSistemiEntities db = new SporStokSistemiEntities();

        // GET: MusteriBilgileris
        public ActionResult Index()
        {
            return View(db.MusteriBilgileri.ToList());
        }

        // GET: MusteriBilgileris/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MusteriBilgileri musteriBilgileri = db.MusteriBilgileri.Find(id);
            if (musteriBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(musteriBilgileri);
        }

        // GET: MusteriBilgileris/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MusteriBilgileris/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UyeID,AdSoyad,Mail,Adres")] MusteriBilgileri musteriBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.MusteriBilgileri.Add(musteriBilgileri);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(musteriBilgileri);
        }

        // GET: MusteriBilgileris/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MusteriBilgileri musteriBilgileri = db.MusteriBilgileri.Find(id);
            if (musteriBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(musteriBilgileri);
        }

        // POST: MusteriBilgileris/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UyeID,AdSoyad,Mail,Adres")] MusteriBilgileri musteriBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.Entry(musteriBilgileri).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(musteriBilgileri);
        }

        // GET: MusteriBilgileris/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MusteriBilgileri musteriBilgileri = db.MusteriBilgileri.Find(id);
            if (musteriBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(musteriBilgileri);
        }

        // POST: MusteriBilgileris/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            MusteriBilgileri musteriBilgileri = db.MusteriBilgileri.Find(id);
            db.MusteriBilgileri.Remove(musteriBilgileri);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
